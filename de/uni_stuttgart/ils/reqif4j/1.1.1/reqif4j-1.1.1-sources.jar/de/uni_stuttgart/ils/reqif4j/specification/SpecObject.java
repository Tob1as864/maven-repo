package de.uni_stuttgart.ils.reqif4j.specification;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.uni_stuttgart.ils.reqif4j.attributes.*;
import de.uni_stuttgart.ils.reqif4j.datatypes.Datatype;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import de.uni_stuttgart.ils.reqif4j.reqif.ReqIFConst;
import de.uni_stuttgart.ils.reqif4j.util.XmlUtils;

public class SpecObject {
	
	
	protected String id;
	protected SpecType specType;
	protected String type;
	protected String alternativeID;
	protected TypeClassifier typeClassifier = TypeClassifier.defaultClassifier();
	protected Map<String, AttributeValue> attributeValues = new HashMap<String, AttributeValue>();
	
	
	
	
	public String getID() {
		return this.id;
	}

	/**
	 * @return the IDENTIFIER of the optional ALTERNATIVE-ID, or null
	 */
	public String getAlternativeID() {
		return this.alternativeID;
	}

	public String getType() {
		return this.type;
	}
	
	public String getSpecType() {
		return this.specType.getType();
	}

	public String getSpecTypeName() {
		return this.specType.getName();
	}

	/**
	 * @return the IDENTIFIER of the spec type this object refers to, or null if
	 *         the reference could not be resolved
	 */
	public String getSpecTypeID() {
		return this.specType == null ? null : this.specType.getID();
	}
	
	public Map<String, AttributeValue> getAttributes() {
		return this.attributeValues;
	}
	
	public Object getAttribute(String attributeName) {
		AttributeValue attributeValue = this.attributeValues.get(attributeName);
		return attributeValue == null ? null : attributeValue.getValue();
	}
	
	public boolean isReq() {
		return this.typeClassifier.isRequirement(this);
	}
	
	public boolean isHeadline() {
		
		if(this.type.equals(ReqIFConst.HEADLINE)) {
			return true;
		}else{
			return false;
		}
	}
	
	public boolean isSubReq() {
		return this.typeClassifier.isSubRequirement(this);
	}
	
	public boolean isText() {
		
		if(!this.isReq() && !this.isHeadline() && !this.isSubReq()) {
			return true;
		}else{
			return false;
		}
	}
	
	
	public SpecObject(Node specObject){
		this.id = specObject.getAttributes().getNamedItem(ReqIFConst.IDENTIFIER).getTextContent();
		this.alternativeID = XmlUtils.alternativeID(specObject);
	}
	
	/**
	 * Creates a spec object from plain values, for documents that are generated
	 * instead of parsed. The content category is derived by the classifier, as
	 * when reading.
	 */
	public SpecObject(String id, SpecType specType, Collection<AttributeValue> attributeValues,
			TypeClassifier typeClassifier) {

		this.id = id;
		this.specType = specType;
		this.typeClassifier = typeClassifier == null ? TypeClassifier.defaultClassifier() : typeClassifier;

		if(attributeValues != null) {
			for(AttributeValue attributeValue: attributeValues) {
				this.attributeValues.put(attributeValue.getName(), attributeValue);
			}
		}
		this.type = this.typeClassifier.classify(this);
	}

	public SpecObject(String id, SpecType specType, Collection<AttributeValue> attributeValues) {
		this(id, specType, attributeValues, TypeClassifier.defaultClassifier());
	}

	public SpecObject(Node specObject, SpecType specType) {
		this(specObject, specType, TypeClassifier.defaultClassifier());
	}

	public SpecObject(Node specObject, SpecType specType, TypeClassifier typeClassifier) {

		this.id = specObject.getAttributes().getNamedItem(ReqIFConst.IDENTIFIER).getTextContent();
		this.alternativeID = XmlUtils.alternativeID(specObject);
		this.specType = specType;
		this.typeClassifier = typeClassifier == null ? TypeClassifier.defaultClassifier() : typeClassifier;

		readAttributeValues(specObject, specType);

		// Classify only after all attribute values are available, so an
		// attribute-based classifier (e.g. the ReqIF Implementation Guide
		// profile) can inspect them.
		this.type = this.typeClassifier.classify(this);
	}

	/**
	 * Reads all attribute values of the given node and fills in default values
	 * for attribute definitions that carry no explicit value. Shared by
	 * {@link SpecObject} and {@link SpecRelation}.
	 */
	protected void readAttributeValues(Node specObject, SpecType specType) {

		// VALUES is located by local name so prefixed ReqIF namespaces work too;
		// only this object's own VALUES is taken, not a nested one.
		Element valuesElement = XmlUtils.firstChildElementByLocalName(specObject, ReqIFConst.VALUES);
		if(valuesElement != null) {

			for(Element attribute: XmlUtils.childElements(valuesElement)) {

				String attValNodeName = XmlUtils.localName(attribute);
				{

					String attributeDefinitionRef = XmlUtils.firstChildElement(
							XmlUtils.firstChildElementByLocalName(attribute, ReqIFConst.DEFINITION)).getTextContent().trim();
					String attributeDefinitionName = specType.getAttributeDefinitions().get(attributeDefinitionRef).getName();
					String attributeValue;
					AttributeDefinition attributeDefinition = specType.getAttributeDefinition(attributeDefinitionRef);
					
					switch(attValNodeName.substring(attValNodeName.lastIndexOf("-")+1)) {
					
						case ReqIFConst.BOOLEAN:		if(attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE) !=null) {
															attributeValue = attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE).getTextContent();
														}else{
															attributeValue = "";
														}
														this.attributeValues.put(attributeDefinitionName, new AttributeValueBoolean(attributeValue, attributeDefinition));
														break;
							
						case ReqIFConst.INTEGER:		if(attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE) !=null) {
															attributeValue = attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE).getTextContent();
														}else{
															attributeValue = "";
														}
														this.attributeValues.put(attributeDefinitionName, new AttributeValueInteger(attributeValue, attributeDefinition));
														break;
							
						case ReqIFConst.STRING:			if(attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE) !=null) {
															attributeValue = attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE).getTextContent();
														}else{
															attributeValue = "";
														}
														this.attributeValues.put(attributeDefinitionName, new AttributeValueString(attributeValue, attributeDefinition));
														break;
							
						case ReqIFConst.ENUMERATION:	// Multiselect: read ALL ENUM-VALUE-REF children, not just the first
														List<String> enumRefs = new ArrayList<String>();
														List<String> enumNames = new ArrayList<String>();
														for(Element ref : XmlUtils.descendantsByLocalName(attribute, ReqIFConst.ENUM_VALUE_REF)) {
															String refID = ref.getTextContent().trim();
															enumRefs.add(refID);
															enumNames.add(specType.getEnumValueName(refID));
														}
														this.attributeValues.put(attributeDefinitionName, new AttributeValueEnumeration(enumNames, enumRefs, attributeDefinition));
														break;
							
						case ReqIFConst.XHTML:			this.attributeValues.put(attributeDefinitionName, new AttributeValueXHTML(attribute, attributeDefinition));
														break;

						case ReqIFConst.DATE:			if(attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE) !=null) {
															attributeValue = attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE).getTextContent();
														}else{
															attributeValue = "";
														}
														this.attributeValues.put(attributeDefinitionName, new AttributeValueDate(attributeValue, attributeDefinition));
														break;

						case ReqIFConst.REAL:			if(attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE) !=null) {
															attributeValue = attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE).getTextContent();
														}else{
															attributeValue = "";
														}
														this.attributeValues.put(attributeDefinitionName, new AttributeValueDouble(attributeValue, attributeDefinition));
														break;

						// Values of datatype kinds the parser does not model are
						// kept generically instead of being dropped, so they
						// survive a round trip.
						default:						if(attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE) !=null) {
															attributeValue = attribute.getAttributes().getNamedItem(ReqIFConst.THE_VALUE).getTextContent();
														}else{
															attributeValue = "";
														}
														this.attributeValues.put(attributeDefinitionName,
																new AttributeValue(attributeValue, attributeDefinition)
																		.setSourceElementName(XmlUtils.localName(attribute)));
														break;
					}
				}
			}
		}
		
		if(this.attributeValues.size() < specType.getAttributeDefinitions().size()) {
			
			for(AttributeDefinition attributeDefinition: specType.getAttributeDefinitions().values()) {
				
				if(!this.attributeValues.containsKey(attributeDefinition.getName())) {

					Datatype datatype = attributeDefinition.getDataType();

					if(datatype == null) {
						throw new ExceptionSpecObject("Attribute definition not existing in ReqIF parser\n", attributeDefinition);
					}

					switch(attributeDefinition.getDataType().getType()) {
					
						case ReqIFConst.BOOLEAN:		this.attributeValues.put(attributeDefinition.getName(), new AttributeValueBoolean(attributeDefinition.getDefaultValue(), attributeDefinition));
														break;
						
						case ReqIFConst.INTEGER:		this.attributeValues.put(attributeDefinition.getName(), new AttributeValueInteger(attributeDefinition.getDefaultValue(), attributeDefinition));
														break;
						
						case ReqIFConst.STRING:			this.attributeValues.put(attributeDefinition.getName(), new AttributeValueString(attributeDefinition.getDefaultValue(), attributeDefinition));
														break;
						
						case ReqIFConst.ENUMERATION:	if(attributeDefinition instanceof AttributeDefinitionEnumeration) {
															AttributeDefinitionEnumeration enumDefinition = (AttributeDefinitionEnumeration) attributeDefinition;
															this.attributeValues.put(attributeDefinition.getName(), new AttributeValueEnumeration(enumDefinition.getDefaultValues(), enumDefinition.getDefaultValueRefs(), attributeDefinition));
														}else{
															this.attributeValues.put(attributeDefinition.getName(), new AttributeValueEnumeration(attributeDefinition.getDefaultValue(), attributeDefinition));
														}
														break;
						
						case ReqIFConst.XHTML:			this.attributeValues.put(attributeDefinition.getName(), new AttributeValueXHTML(attributeDefinition.getDefaultValue(), attributeDefinition));
														break;

						case ReqIFConst.DATE:			this.attributeValues.put(attributeDefinition.getName(), new AttributeValueDate(attributeDefinition.getDefaultValue(), attributeDefinition));
														break;

						case ReqIFConst.DOUBLE:			this.attributeValues.put(attributeDefinition.getName(), new AttributeValueDouble(attributeDefinition.getDefaultValue(), attributeDefinition));
														break;

						default:						break;
					}
				}
			}
		}
	}

}
