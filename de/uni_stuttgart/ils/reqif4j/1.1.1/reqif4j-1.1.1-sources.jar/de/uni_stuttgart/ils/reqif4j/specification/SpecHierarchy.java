package de.uni_stuttgart.ils.reqif4j.specification;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import de.uni_stuttgart.ils.reqif4j.attributes.AttributeValue;
import de.uni_stuttgart.ils.reqif4j.attributes.AttributeValueXHTML;
import de.uni_stuttgart.ils.reqif4j.attributes.AttributeValueXHTMLElementList;
import de.uni_stuttgart.ils.reqif4j.reqif.ReqIFConst;
import de.uni_stuttgart.ils.reqif4j.util.XmlUtils;
import de.uni_stuttgart.ils.reqif4j.xhtml.XHTMLNode;
import de.uni_stuttgart.ils.reqif4j.xhtml.XHTMLElementDiv;

public class SpecHierarchy {
	
	
	private String specHierarchyID;
	private String alternativeID;
	private int hierarchyLvl;
	private int section;
	private SpecObject specObject;
	private Map<String, SpecHierarchy> children = new LinkedHashMap<String, SpecHierarchy>();
	
	
	
	
	public String getSpecHierarchyID() {
		return this.specHierarchyID;
	}

	/**
	 * @return the IDENTIFIER of the optional ALTERNATIVE-ID, or null
	 */
	public String getAlternativeID() {
		return this.alternativeID;
	}
	
	public String getSpecObjectID(){
		return this.specObject.getID();
	}
	
	public int getHierarchyLvl() {
		return this.hierarchyLvl;
	}
	
	public int getSection() {
		return this.section;
	}
	
	public SpecObject getSpecObject() {
		return this.specObject;
	}
	
	public Map<String, AttributeValue> getAttributes() {
		return this.specObject.getAttributes();
	}
	
	public Object getAttribute(String attributeName) {
		return (Object)this.specObject.getAttribute(attributeName);
	}
	
	public AttributeValueXHTMLElementList getXHTMLContent() {
		for(AttributeValue attributeValue: this.specObject.getAttributes().values()) {
			// getValue() returns the rendered string, so the element list has
			// to be fetched via its dedicated getter (the former cast threw
			// ClassCastException on every call).
			if(attributeValue instanceof AttributeValueXHTML) {
				return ((AttributeValueXHTML)attributeValue).getElementList();
			}
		}
		return null;
	}
	
	public List<XHTMLNode> getXHTMLDivContent() {
		for(AttributeValue attributeValue: this.specObject.getAttributes().values()) {
			if(attributeValue instanceof AttributeValueXHTML) {
				XHTMLElementDiv value = ((AttributeValueXHTML)attributeValue).getDivValue();
				if(value != null) {
					return value.getChildren();
				}
			}
		}
		return null;
	}
	
	public String getSpecType() {
		return this.specObject.getSpecType();
	}
	
	public String getSpecTypeName() {
		return this.specObject.getSpecTypeName();
	}
	
	public String getType() {
		return this.specObject.getType();
	}
	
	public boolean isReq() {
		if(this.specObject.isReq()) {
			return true;
		}else{
			return false;
		}
	}
	
	public boolean isDef() {
		if(this.specObject.isReq() && this.section == 1) {
			return true;
		}else{
			return false;
		}
	}
	
	public boolean isHeadline() {
		if(this.specObject.isHeadline()) {
			return true;
		}else{
			return false;
		}
	}
	
	public boolean isSubReq() {
		if(this.specObject.isSubReq()) {
			return true;
		}else{
			return false;
		}
	}
	
	public boolean isText() {
		if(this.specObject.isText()) {
			return true;
		}else{
			return false;
		}
	}
	
	public List<SpecHierarchy> getChildren() {
        return new ArrayList<SpecHierarchy>(this.children.values());
	}
	
	public List<SpecHierarchy> getAllChildren() {
		
		List<SpecHierarchy> allChildren = new ArrayList<SpecHierarchy>();
		for(SpecHierarchy specHierarchy: this.children.values()) {
			allChildren.add(specHierarchy);
			for(SpecHierarchy child: specHierarchy.getAllChildren()) {
				allChildren.add(child);
			}
		}
		
		return allChildren;
	}
	
	
	
	
	/**
	 * Creates a hierarchy node from plain values, for documents that are
	 * generated instead of parsed.
	 */
	public SpecHierarchy(String specHierarchyID, int hierarchyLvl, int section, SpecObject specObject,
			List<SpecHierarchy> children) {

		this.specHierarchyID = specHierarchyID;
		this.hierarchyLvl = hierarchyLvl;
		this.section = section;
		this.specObject = specObject;

		if(children != null) {
			for(SpecHierarchy child: children) {
				this.children.put(child.getSpecHierarchyID(), child);
			}
		}
	}

	public SpecHierarchy(int hierarchyLvl, int section, Node specHierarchy, Map<String, SpecObject> specObjects) {
		
		this.hierarchyLvl = hierarchyLvl;
		this.section = section;
		this.specHierarchyID = specHierarchy.getAttributes().getNamedItem(ReqIFConst.IDENTIFIER).getTextContent();
		this.alternativeID = XmlUtils.alternativeID(specHierarchy);
		
		Element object = XmlUtils.firstChildElementByLocalName(specHierarchy, ReqIFConst.OBJECT);
		Element specObjectRef = XmlUtils.firstDescendantByLocalName(object, ReqIFConst.SPEC_OBJECT_REF);
		if(specObjectRef != null) {
			this.specObject = specObjects.get(specObjectRef.getTextContent().trim());
		}

		Element childrenElement = XmlUtils.firstChildElementByLocalName(specHierarchy, ReqIFConst.CHILDREN);
		if(childrenElement != null) {

			for(Element newSpecHierarchy: XmlUtils.childElements(childrenElement)) {

				String specHierarchyID = XmlUtils.attribute(newSpecHierarchy, ReqIFConst.IDENTIFIER);

				this.children.put(specHierarchyID, new SpecHierarchy(this.hierarchyLvl+1, section, newSpecHierarchy, specObjects));
			}
		}
	}
	
}
